inductive ℕ where
  | zero : ℕ
  | succ : ℕ → ℕ
  deriving Repr

open ℕ

def add (m n : ℕ) : ℕ :=
  match n with
  | zero   => m
  | succ k => succ (add m k)

instance : Add ℕ where
  add := add

def mul (m n : ℕ) : ℕ :=
  match n with
  | zero    => zero
  | succ k  => (mul m k) + m

instance : Mul ℕ where
  mul := mul

-- Axioms of Peano Arithmetic
theorem PA1 (m : ℕ) : ¬(succ m = zero) := by intro f;injection f
theorem PA2 (m n : ℕ) : succ m = succ n → m = n := by intro h;injection h
theorem PA3 (m : ℕ) : m + zero = m := by rfl
theorem PA4 (m n : ℕ) : m + (succ n) = succ (m + n) := by rfl
theorem PA5 (m : ℕ) : m * zero = zero := by rfl
theorem PA6 (m n : ℕ) : m * (succ n) = (m * n) + m := by rfl

-- For each of the theorems below, replace "sorry" with a tactic proof.

-- Question 1
theorem zero_add : ∀ x : ℕ, zero + x = x :=
  sorry

-- Question 2
theorem zero_mul : ∀ x : ℕ, zero * x = zero :=
  sorry

-- Question 3
theorem mul_one : ∀ x : ℕ, x * (succ zero) = x :=
  sorry

-- Question 4
theorem succ_add : ∀ x y : ℕ, (succ x) + y = succ (x + y) :=
  sorry

-- Question 5
theorem add_assoc : ∀ x y z : ℕ, (x + y) + z = x + (y + z) :=
  sorry

-- Question 6
theorem add_comm : ∀ x y : ℕ, x + y = y + x :=
  sorry

-- Question 7
theorem succ_mul : ∀ x y : ℕ, (succ x) * y = x * y + y :=
  sorry

-- Question 8
theorem mul_comm : ∀ x y : ℕ, x * y = y * x :=
  sorry

-- Question 9
theorem add_mul : ∀ x y z : ℕ, (y + z) * x = y * x + z * x :=
  sorry

-- Question 10
theorem mul_assoc : ∀ x y z : ℕ, (x * y) * z = x * (y * z) :=
  sorry

-- We now add ≤ predicate to our formal description of ℕ
def leq (m n : ℕ) := (∃ x : ℕ, n = m + x)
-- Since it's defined using the ∃ quantifier, you will need
-- to use the corresponding ∃ terms/tactics in Lean.
--
-- apply Exists.intro a
-- ... This reduces the goal to a proof that a has the required
-- property.

-- To use an hypothesis of the form  t : a ≤ b
-- One can write "apply Exists.elim t"
-- Then introduce the term and proof with intro.

instance : LE ℕ where
  le := leq

-- Question 11
theorem leq_refl : ∀ x : ℕ, x ≤ x :=
  sorry

-- Question 12
theorem zero_leq : ∀ x : ℕ, zero ≤ x :=
  sorry

-- Question 13
theorem leq_succ : ∀ x : ℕ, x ≤ succ x :=
  sorry

-- Question 14
theorem leq_trans : ∀ x y z : ℕ, (x ≤ y) ∧ (y ≤ z) → x ≤ z :=
  sorry

-- You may require the following two theorems to write
-- a proof of Question 15. These theorems: add_eq_self
-- and add_eq_zero have already been proved.
-- You may use them, or not, as is.

theorem add_eq_self : ∀ x y : ℕ, x + y = x → y = zero :=
  by
    intro a b
    intro h₁
    induction a with
    | zero      => rw [zero_add] at h₁
                   exact h₁
    | succ n ih => rw [succ_add] at h₁
                   have h₂ := PA2 (n+b) n h₁
                   exact ih h₂

theorem add_eq_zero : ∀ x y : ℕ, x + y = zero -> x = zero :=
  by
    intro a b
    intro h₁
    induction a with
    | zero      => rfl
    | succ n ih => rw [succ_add] at h₁
                   injection h₁

-- Question 15
theorem leq_antisymm : ∀ x y : ℕ, (x ≤ y) ∧ (y ≤ x) → x = y := sorry
