import Formal

def main : IO Unit :=
  IO.println s!"Hello, {hello}!"
